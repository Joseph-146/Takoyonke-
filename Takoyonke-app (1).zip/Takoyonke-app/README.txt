TAKOYONKE APP

Open index.html in any browser. No install needed.

Employees: Register (name, Gmail, password) > Log in > choose branch > your original app.
Owner:     Owner tab > enter your Host ID > dashboard.

REAL-TIME SYNC (across phones)
1. console.firebase.google.com > Create project > Build > Realtime Database > Create database (test mode).
2. Copy the database URL (https://xxxx-default-rtdb.firebaseio.com).
3. In index.html find   var FB_URL="";   and paste the URL between the quotes. Save.
4. Put the same index.html on every phone (or host it, e.g. Firebase Hosting / Netlify).
The owner badge shows Live when connected, "This device only" when FB_URL is empty.
